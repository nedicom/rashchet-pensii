<?php

	$description ='Это единственный калькулятор, который позовялет проверить правильность начисления уже существующей пенсии или размер пенсии на дату выхода';
	$title = 'Расчет назначенной пенсии';
	include 'src/meta.php';
	
	include 'src/header.php';
	
	include 'header-raschet.php';
	
	include 'form-prostoy-raschet.php';
	
	include 'comment/commentform.php';
	
	include 'src/footer.php';
	
				echo '<div class="toast-container position-absolute p-2 bottom-0 end-0 d-none d-sm-block">		
				<div class="toast show">
				
				    <div class="toast-header">
						<i class="fa-solid fa-calculator"></i>
						<strong class="me-auto mx-3">Поделиться калькулятором</strong>
						<small class="text-muted">3 сек</small>
						<button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Закрыть"></button>
					</div>
					<div class="toast-body">					
						Поделитесь, чтобы не потерять сайт. Просто отправьте ссылку близкому человеку 
						<div class="mt-2 pt-2 border-top text-center">						
							<script src="https://yastatic.net/share2/share.js"></script>
							<div class="ya-share2" data-curtain data-shape="round" data-services="vkontakte,odnoklassniki,telegram,viber,whatsapp,moimir"></div>
						</div>						
					</div>
					</div>
				</div>
			</div>';
?>