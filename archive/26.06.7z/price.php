<?php
	$description ='Узнайте об условиях выполнения расчета';
	$title = 'Цена расчета пенсии';
	include 'src/meta.php';
	include 'src/header.php';
	
	
    

echo '

<div class="container py-3">

<div class="pricing-header p-3 pb-md-4 mx-auto text-center">
      <h1 class="display-4 fw-normal">Цена</h1>
      <p class="fs-5 text-muted">Расчет необходим, чтобы определить причину расхождений в размере пенсии и направить заявление в ПФР или суд для перерасчета</p>
    </div>
	
  <main>
    <div class="row row-cols-1 row-cols-md-2 mb-3 text-center">
      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal">Бесплатные </br> образцы</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title">0<small class="text-muted fw-light"> рублей</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>образец расчета</li>
              <li>образец заявления</li>
              <li>можно пользоваться калькулятором</li>
			  <li>&nbsp;</li>
			  <li>&nbsp;</li>
            </ul>
            <a class="w-100 btn btn-lg btn-primary" href="obrazec.php" role="button">скачать</a>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm border-primary">
          <div class="card-header py-3 text-white bg-primary border-primary">
            <h4 class="my-0 fw-normal">Пенсионный</br> калькулятор</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title">1000<small class="text-muted fw-light"> рублей</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>Можно скачать расчет на 17 страницах</li>
              <li>Можно скачать заявление в ПФР/суд</li>
              <li>Данные сохраняются в личном кабинете</li>
              <li>Бесплатная консультация юриста</li>
			  <li>Помощь в расчете показателей</li>
            </ul>
			<a class="w-100 btn btn-lg btn-primary" href="zakazat-rashchet.php" role="button">заказать</a>
          </div>
        </div>
      </div>
      
    </div>

    <h2 class="display-6 text-center mb-4">Сравните преимущества</h2>

    <div class="table-responsive">
      <table class="table text-center">
        <thead>
          <tr>
            <th style="width: 34%;"></th>
            <th style="width: 22%;">Бесплатный</th>
            <th style="width: 22%;">Калькулятор</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row" class="text-start">Консультации с юристом</th>
            <td>нет</td>
            <td>да</svg></td>
          </tr>
          <tr>
            <th scope="row" class="text-start">Скачать расчет</th>
            <td>только образец</td>
            <td>личный расчет</td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <th scope="row" class="text-start">сопроводительное заявление</th>
			<td>только образец</td>
            <td>личное заявление</td>
          </tr>
          <tr>
            <th scope="row" class="text-start">Расчет показателей</th>
			<td>нет</td>
            <td>юрист расчитает за Вас</td>
          </tr>
          <tr>
            <th scope="row" class="text-start">Личный кабинет</th>
			<td>нет</td>
            <td>да</td>
          </tr>
        </tbody>
      </table>
    </div>
  </main>


</div>
  
  
';


	include 'src/footer.php';
	
  	?>