<?php
    $con = mysqli_connect("a140468.mysql.mchost.ru","a140468_pfr","re0pR8jss0","a140468_pfr");
    // Check connection
	$con->query("SET NAMES 'utf8'");	  
			  if ($con->connect_error) {
				die($connectbutton="Соединение не удалось: " . $con->connect_error);
				}
				$connectbutton="Соединение успешно";
?>