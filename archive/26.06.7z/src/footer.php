<?php
echo '
			<div class="toast-container position-absolute p-2 top-0 start-50 translate-middle-x">		
				<div class="toast show">
				
				    <div class="toast-header">
						<i class="fa-solid fa-calculator"></i>
						<strong class="me-auto mx-3">Запомнить сайт</strong>
						<small class="text-muted">прямо сейчас</small>
						<button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Закрыть"></button>
					</div>
					<div class="toast-body">					
						Поделитесь, чтобы не потерять сайт 
						<div class="mt-2 pt-2 border-top text-center">						
							<script src="https://yastatic.net/share2/share.js"></script>
							<div class="ya-share2" data-curtain data-shape="round" data-services="vkontakte,odnoklassniki,telegram,viber,whatsapp,moimir"></div>
						</div>						
					</div>
					</div>
				</div>
			</div>
			
<footer class="container py-5">

  <div class="row">
    <div class="col-12 col-md">
      <i class="fa-solid fa-calculator"></i><title>Product</title><circle cx="12" cy="12" r="10"/><path d="M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83m13.79-4l-5.74 9.94"/></svg>
      <small class="d-block mb-3 text-muted">&copy; 2015–2022</small>
	</div>
	
	<div class="col-12 col-md">
      <h5>Скачать на телефон</h5>
      <ul class="list-unstyled text-small">
        <li><a href="https://store.nashstore.ru/store/629f2178fb3ed3467803c87d" target="_blank" class="mb-3"><br>
			<img alt="пенсионный калькулятор РФ" data-align="center" width="200px" data-entity-type="file" data-entity-uuid="74ba8fe2-baa4-43e0-8bf4-c0b72cfed2a1" src="img/ns.svg">
		</a></li>
		<li><a href="https://play.google.com/store/apps/details?id=com.markmina.pensioncalculator" target="_blank"><br>
			<img alt="пенсионный калькулятор РФ" data-align="center" width="200px" data-entity-type="file" data-entity-uuid="74ba8fe2-baa4-43e0-8bf4-c0b72cfed2a1" src="img/gp.png">
		</a></li>
      </ul>
    </div>
	

    <div class="col-12 col-md">
      <h5>Дополнения</h5>
      <ul class="list-unstyled text-small">
        <li><a class="link-secondary" href="http://rashchet-pensii.nedicom.ru/examples/rasschet-pensii-obrazec.pdf" download>Образец расчета</a></li>
        <li><a class="link-secondary" href="http://rashchet-pensii.nedicom.ru/examples/soprovoditelnaya.pdf" download>Образец заявления</a></li>
        <li><a class="link-secondary" href="#">Политика неразглашения</a></li>
        <li><a class="link-secondary" href="#">Политика использования персональных данных</a></li>
        <li><a class="link-secondary" href="#">Использование cookie</a></li>
      </ul>
    </div>    
    
    <div class="col-12 col-md">
      <h5>Наша команда</h5>
      <ul class="list-unstyled text-small">
        <li><a class="link-secondary" href="#">Команда</a></li>
        <li><a class="link-secondary" href="#">Адрес</a></li>
        <li><a class="link-secondary" href="contacts.php">Контакты</a></li>
      </ul>
    </div>
  </div>
</footer>

</body>
</html>';

	
  	?>