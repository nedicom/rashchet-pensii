<?php
	include 'src/meta.php';
	$description ='Это единственный калькулятор, который позовялет проверить правильность начисления уже существующей пенсии или размер пенсии на дату выхода';
	$title = 'Расчет назначенной пенсии';

	include 'src/header.php';
	
	
	include 'form-raschet.php';

	
	include 'src/footer.php';
	
	
  	?>