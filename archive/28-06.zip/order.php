<?php
	$description ='Ваш личный кабинет на этом сайте';
	$title = 'Заказ расчета пенсии';
	include 'src/meta.php';
	include 'src/header.php';
	
	
    

echo '

<div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold">Личный кабинет не доступен</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4">Для получения доступа перейдите на страницу заказа.</p>
      <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
            <a class="w-100 btn btn-lg btn-primary px-4 gap-3" href="zakazat-rashchet.php" role="button">перейти</a>
      </div>
    </div>
  </div>
  
  ';


	include 'src/footer.php';
	
  	?>