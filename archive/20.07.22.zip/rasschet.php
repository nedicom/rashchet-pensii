<?php
	$description ='Результат расчета после заполнения формы';
	$title = 'Результат расчета';
	include 'src/meta.php';
	include 'src/header.php';
    
		function pensFond($sk, $zp, $punkt, $szp, $pns, $T, $kv, $pk2, $spk, $ipkn, $nadb) {
			if($punkt=='on'){
				$propzp = $zp/ $szp;
					if ($propzp<1.2){						
						$pk1 = (($sk * $propzp * '1671.00') - '450.00') * $pns * $T *'5.61481656';
						$rp = $sk * $propzp * '1671.00';
					}
					else {
						$pk1 = (($sk * '1.2' * '1671.00') - '450.00') * $pns * $T *'5.61481656';
						$rp = $sk * '1.2' * '1671.00';
					};
			}
			else{
				$pk1 = (($sk * $zp/'60')-'450.00') * $pns * $T *'5.61481656';		
			};
			$sv = $pk1/'100'*('10' + $kv);
			$pk = $pk1 + $sv + $pk2;
			$p = $pk/$T;
			$ipks = $p/'64.1';
			$ipk = $ipks + $ipkn;
			$spst = $ipk*$spk;
			$pensiya = ($ipk*$spk) + $nadb;
			$pensiya = round($pensiya, 2);	
		return $pensiya;		
		};
		
	$pensFond = pensFond($_POST['sk'], $_POST['zp'], $_POST['punkt'], $_POST['szp'], $_POST['pns'], $_POST['T'],
	$_POST['kv'], $_POST['pk2'], $_POST['spk'], $_POST['ipkn'], $_POST['nadb']);	
		
	echo'	<div class="col-md-8 p-lg-5 mx-auto mt-5">
				<h1 class="display-4 fw-normal">Ваша пенсия<small class="text-muted"> составляет</small></h1>
				<h1 class="display-4 fw-normal">'.$pensFond.' <small class="text-muted"> рублей</small></h1>
				<div class="text-center px-4">
					<a class="btn mt-2 btn-outline-secondary btn-lg text-center" href="zakazat-rashchet.php" target="_blank"><i class="fa fa-download"></i> нажмите, если нужно скачать расчет</a>
				</div>
			</div>
		';
	
	include 'example.php';						
					
	echo'	<div class="px-4 py-2 my-2 text-center">
				<a class="btn btn-primary  mt-1" href="http://rashchet-pensii.nedicom.ru/examples/rasschet-pensii-obrazec.pdf" target="_blank" role="button"><i class="fa fa-eye" download></i> Смотреть образец расчета</a>
				<a class="btn btn-primary  mt-1" href="http://rashchet-pensii.nedicom.ru/examples/soprovoditelnaya.pdf" target="_blank" role="button"><i class="fa fa-eye" download></i> Смотреть образец заявления</a>
<				<p class="lead mb-4 mt-3">Внимание, образцы защищены авторским правом. Допускается использование исключительно в личных целях.</p>
		</div>
		';
	




	include 'src/footer.php';
	

$pathword = "files/raschet.docx";
$psthxml = "files/document.xml";


//присвоить переменные
	$Rekvizitydogovora = array(
		'$sk', '$zp', '$punkt', '$szp', '$pns', '$T', '$kv', '$pk2', '$spk', '$ipkn', '$nadb', '$pensiya'
	);

	$Rekvizitydogovoravar = array(
		$_POST['sk'], $_POST['zp'], $_POST['punkt'], $_POST['szp'], $_POST['pns'], $_POST['T'],
			$_POST['kv'], $_POST['pk2'], $_POST['spk'], $_POST['ipkn'], $_POST['nadb'], $pensFond
	);
	
//изменить адрес
echo '<a class="waves-effect waves-light btn-large" href = "http://rashchet-pensii.nedicom.ru/files/download.php"><i type="button" class="btn btn-success">скачать документ</i></a> ';
print_r ($pensFond);

	$zip = new ZipArchive;  //Запись в файл
//phpinfo(INFO_MODULES);
	if($zip->open('files/raschet.docx') === TRUE) {
		echo $pensiya;
		/*открываем наш шаблон для чтения (он находится вне документа)
		и помещаем его содержимое в переменную $content*/
		$handle = fopen($psthxml, "r");
		$content = fread($handle, filesize($psthxml));
		fclose($handle);
		//print_r($content);
		//echo 'ok';
		/*Далее заменяем все что нам нужно например так (используем массивы)*/
		$content = str_replace($Rekvizitydogovora, $Rekvizitydogovoravar, $content);
		/*Удаляем имеющийся в архиве document.xml*/
		$zip->deleteName('word/document.xml');
		/*Пакуем созданный нами ранее и закрываем*/
		$zip->addFromString('word/document.xml',$content);
		$zip->close();
	}
?>