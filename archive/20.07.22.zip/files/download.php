<?php
//редактируем адрес и название файла
$file = ("http://rashchet-pensii.nedicom.ru/files/raschet.docx");
header ("Content-Type: application/octet-stream");
header ("Accept-Ranges: bytes");
header ("Content-Length: ".filesize($file));
header ("Content-Disposition: attachment; filename=расчет_пенсии.docx");  
readfile($file);
?>