<?php
	$description ='Упрощенная версия расчета пенсии онлайн. Вы можете оформить такой расчет не обладая специальными знаниями';
	$title = 'Расчет назначенной пенсии в простом режиме';
	include 'src/meta.php';
	
	include 'src/header.php';
	
	include 'header-raschet.php';
	
	include 'form-raschet.php';

	include 'example.php';	
		
	include 'src/footer.php';	
?>