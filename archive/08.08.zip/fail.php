<?
$inv_id = $_REQUEST["InvId"];
echo '<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
	</head>
';
echo "Что-то пошло не так(. Оплата не прошла. Заказ# $inv_id\n";
?>


