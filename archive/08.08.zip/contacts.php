<?php
	$description ='Здесь данные для связи с разработчиками';
	$title = 'Контакты';
	include 'src/meta.php';
	include 'src/header.php';
	
	
    

echo '
<div class="px-4 py-5 my-5 text-center">
	<h1 class="display-5 fw-bold">+79788838978</h1>
    <h1 class="display-5 fw-bold">m6132@yandex.ru</h1>
	<p class="lead mb-4">Вы можете позвонить или написать нам, если у Вас появились вопросы</p>
</div>';


	include 'src/footer.php';
	
  	?>
	