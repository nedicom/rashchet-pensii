<?php
	$description ='Заказажите расчет пенсии, чтобы предъявить его пенсионному фонду!';
	$title = 'Заказать расчет пенсии';
	include 'src/meta.php';
	include 'src/header.php';
	
	
    

echo '

<div itemscope itemtype="http://schema.org/Product" class="container my-5">
    <div class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
      <div class="col-lg-7 p-3 p-lg-5 pt-lg-3">
        <h1 itemprop="name" class="display-4 fw-bold lh-1 text-center">Заказ расчета</h1>';
		
		if(empty($_SESSION['client_id'])){			
		echo '
        <p itemprop="description" class="lead mt-3">Войдите на сайт перед проведением оплаты</p>
		<p><a href="https://oauth.yandex.ru/authorize?client_id=f63f07d2b06d40dd849eb6aeb83f8a1d&amp;redirect_uri=https://rashchet-pensii.nedicom.ru&amp;response_type=code&amp;state=123" class="d-inline-flex m-1 btn btn-primary btn-lg d-flex" role="button">Войти</a>
		</p>
		';
		}
		else{
          $merchant_login = "nedicom";
          $password_1 = "MlyF3G73kgfx0xNMty2m";          
          $description = "Расчет пенсии онлайн";
		  
		  $invid = ($_SESSION['client_id']);
		  
          $out_sum = "2.00";
          $signature_value = md5("$merchant_login:$out_sum:$invid:$password_1");
		  
		  // build URL
          $url = "https://auth.robokassa.ru/Merchant/Index.aspx?MerchantLogin=".$merchant_login."&out_sum=".$out_sum."&InvId=".$invid."&Description=".$description."&SignatureValue=".$signature_value."";
		  echo '
		  <div class="d-grid gap-2 col-6 mx-auto">
		  <a class="btn btn-primary btn-lg my-3 w-100" href="'.$url.'" role="button">Заказать </a>
		  <p>номер заказа - '.$invid.'</p></div>';
		  
			}
		
		echo '
        <div itemprop="offers" itemscope itemtype="http://schema.org/AggregateOffer">
		<meta itemprop="priceCurrency" content="RUB">
        <link itemprop="availability" href="http://schema.org/InStock">
		<p class="lead mt-4">Стоимость расчета составляет: <span class="fw-bold"><span itemprop="lowPrice">2 рубля</span> 
		
			<ul class="list-group list-group-flush">
			<div class="fw-bold">В заказ входит:</div>
				  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> Расчет в pdf формате</li>
				  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> Возможность редактировать данные</li>
				  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> Неограниченное количество скачиваний</li>
				  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> Сопроводительное в ПФР или суд</li>
				  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> Сохранение данных в личном кабинете</li>

			</ul>
		</p>
		</div>
      </div>
      <div class="col-lg-4 offset-lg-1 p-0 overflow-hidden shadow-lg d-none d-md-block">
          <img itemprop="image" class="rounded-lg-3" src="img/6.jpg" alt="образец расчета пенсии" width="520" >
		  
      </div>
    </div>
  </div>
  
    <!-- disable button -->
		<script type="text/javascript">
			function stoppedTyping(){
			  var keys =  document.getElementById("phonebtn").value;
				if(keys.length > 7) { 
					document.getElementById("btngo").disabled = false; 
				} else { 
					document.getElementById("btngo").disabled = true;
				}
			}			
		</script>
 
';

	include 'example.php';	

	include 'src/footer.php';
	
			//скрипт отправки телефона на почту
			//<form class="form-inline" action="/send.php" method="post">
			//<div class="form-group text-center">
			//<input type="tel" id="phonebtn" onkeyup="stoppedTyping()" name="myphone" class="btn-lg fw-bold d-block" placeholder="+7">
			//<button type="submit" class="btn btn-outline-primary btn-lg d-block mt-3" id="btngo" disabled>отправить</button></div>
			//</form> 
	
  	?>