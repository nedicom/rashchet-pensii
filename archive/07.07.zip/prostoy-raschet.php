<?php
	$description ='Это единственный калькулятор, который позовялет проверить правильность начисления уже существующей пенсии или размер пенсии на дату выхода';
	$title = 'Расчет назначенной пенсии в режиме эксперта';
	include 'src/meta.php';
	
	include 'src/header.php';
	
	include 'header-raschet.php';
	
	include 'form-raschet.php';

	include 'example.php';	
		
	include 'src/footer.php';	
?>