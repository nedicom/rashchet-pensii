<?php

	echo '
		<div class="col-md-8 container p-lg-5 mx-auto my-5 rounded-3 border shadow-lg">
		  <h1 class="display-4 fw-normal text-center"><a href="#start">начать расчет</a></h1>
				<div class="d-flex justify-content-md-center mt-3">
				<ul class="list-group list-group-flush">
				<div class="fw-bold">Приготовьте:</div>
					  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> трудовую книжку</li>
					  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> справку о зарплате (если есть)</li>
					  <li class="list-group-item"><i class="fa fa-check-square-o" aria-hidden="true"></i> выписку из лицевого счета</br>
					  <a href="https://www.gosuslugi.ru/10042/1/info" target="_blank">Заказать
					  <img alt="пенсионный калькулятор РФ" class="mx-1" data-align="center" width="24px" data-entity-type="file" src="img/gu.png"></a></li>
					  
				</ul>
			</div>	
			<div class="d-flex justify-content-md-center mt-3">
				<a class="btn btn-outline-primary btn-lg" href="zakazat-rashchet.php" target="_blank">нажмите, если нужна помощь</a>
			</div>	
		  
		</div>
		

		
	';
?>